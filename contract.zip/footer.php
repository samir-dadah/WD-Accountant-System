<footer>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 text-center">

                © All Copyright <?php echo date('Y')?> by <?php echo get_s('company_name');?>

            </div>
        </div>
    </div>
</footer>
</body>

</html>